-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               8.0.31 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for hibernate_table_relation
CREATE DATABASE IF NOT EXISTS `hibernate_table_relation` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hibernate_table_relation`;

-- Dumping structure for table hibernate_table_relation.answer_info
CREATE TABLE IF NOT EXISTS `answer_info` (
  `answer_id` bigint NOT NULL,
  `answer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table hibernate_table_relation.answer_mo_info
CREATE TABLE IF NOT EXISTS `answer_mo_info` (
  `answer_id` bigint NOT NULL,
  `answer` varchar(255) DEFAULT NULL,
  `question_question_id` bigint DEFAULT NULL,
  PRIMARY KEY (`answer_id`),
  KEY `FKbo6bexqfwav3v79pfoj0o6ceh` (`question_question_id`),
  CONSTRAINT `FKbo6bexqfwav3v79pfoj0o6ceh` FOREIGN KEY (`question_question_id`) REFERENCES `question_om_info` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table hibernate_table_relation.emp
CREATE TABLE IF NOT EXISTS `emp` (
  `eid` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table hibernate_table_relation.emp_pro
CREATE TABLE IF NOT EXISTS `emp_pro` (
  `eid` int NOT NULL,
  `pid` int NOT NULL,
  KEY `FK93htbnyuein2k7r8p83s0ni1e` (`pid`),
  KEY `FKa6v854deiw8cl2exr9eu53grg` (`eid`),
  CONSTRAINT `FK93htbnyuein2k7r8p83s0ni1e` FOREIGN KEY (`pid`) REFERENCES `project` (`pid`),
  CONSTRAINT `FKa6v854deiw8cl2exr9eu53grg` FOREIGN KEY (`eid`) REFERENCES `emp` (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table hibernate_table_relation.project
CREATE TABLE IF NOT EXISTS `project` (
  `pid` int NOT NULL,
  `project_nmae` varchar(255) DEFAULT NULL,
  `project_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table hibernate_table_relation.question_info
CREATE TABLE IF NOT EXISTS `question_info` (
  `question_id` bigint NOT NULL,
  `question` varchar(255) DEFAULT NULL,
  `aid_key` bigint DEFAULT NULL,
  PRIMARY KEY (`question_id`),
  KEY `FKllm3y91ba00ddtn1uq8jf4fre` (`aid_key`),
  CONSTRAINT `FKllm3y91ba00ddtn1uq8jf4fre` FOREIGN KEY (`aid_key`) REFERENCES `answer_info` (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table hibernate_table_relation.question_om_info
CREATE TABLE IF NOT EXISTS `question_om_info` (
  `question_id` bigint NOT NULL,
  `question` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
